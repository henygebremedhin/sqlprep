
1.
SELECT B.starttime
FROM cd.bookings AS B
JOIN cd.members AS M
ON B.memid = M.memid
WHERE M.firstname = 'David' AND M.surname = 'Farrell';


2. 
SELECT B.starttime, F.name AS facility_name
FROM cd.bookings AS B
JOIN cd.facilities AS F
ON B.facid = F.facid
WHERE F.name LIKE 'Tennis Court%'
 AND CAST(B.starttime AS DATE) ='2012-09-21'
ORDER BY B.starttime;

3. 

SELECT DISTINCT W.firstname, W.surname
FROM cd.members AS M
JOIN cd.members AS W
ON M.recommendedby = W.memid
ORDER BY W.surname, W.firstname;

